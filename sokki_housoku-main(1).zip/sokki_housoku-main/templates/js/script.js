/*
From https://cssanimation.rocks/courses/animation-101/
*/
